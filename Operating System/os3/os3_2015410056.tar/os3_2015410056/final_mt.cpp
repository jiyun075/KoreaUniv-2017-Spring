#include <stdio.h>
#include <unistd.h>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <string>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <vector>
#include <sys/syscall.h>

#define CHECK_MICRO_SEC 500000 //500000 microsec == 0.5 sec
#define FASTER 326
#define SLOWER 327

using namespace std;

void check_dir();
vector<string> infoExtract(char*);
int storeInfo(vector<string>);
double cpuUsageCalc(vector<string>);
int checkBenchmark1(vector<string>);
int checkBenchmark2(vector<string>);
void callSyscall(char*);

int db_cnt = 0;

vector<string> db; //Monitoring TOOL Database
int end = 0;

int bm_1_pid = -1; //pid for  syscall
int bm_2_pid = -1;

int bm_1_stat = 0; //state of benchmark
int bm_2_stat = 0; //0: initial value / 1: running / 2: exit after execution

int main()
{
	char* bm1;
	char* bm2;
	string str1 = "(benchmark1)";
	string str2 = "(benchmark2)";

	bm1 = (char *)str1.c_str();
	bm2 = (char *)str2.c_str();

	db.push_back("start");
	printf("**MONITORING TOOL START**\n\n");
	while(end < 2)
	{
		check_dir();
		if(bm_1_stat == 3){
			callSyscall(bm1);
		}
		if(bm_2_stat == 3){
			callSyscall(bm2);
		}
		usleep(CHECK_MICRO_SEC);
	}
	printf("**MONITORING TOOL EXIT**\n");
	return 0;
}

void check_dir()
{
	DIR *dp = NULL;

	struct dirent* entry = NULL;
	char path[50];
	vector<string> process;
	int i;
	int temp_val1;
	int temp_val2;
	bool bm_1_tf = false;
	bool bm_2_tf = false;

	if((dp = opendir("/proc")) == NULL)
	{
		printf("Error: Inaccessible Directory\n");
		exit(0);
	}

	while(true)
	{
		entry = readdir(dp);
		if(entry == NULL)
			break;

		if((entry -> d_name[0] == '.') || (entry -> d_name[0] > 57))
			continue; //except file or dir start with . proc dir start with number

		sprintf(path,"/proc/%s/stat", entry -> d_name); //path <- /proc/PID/stat

		if(access(path, F_OK) != 0)
			continue;

		process = infoExtract(path);

		/*check if it is benchmark*/
		temp_val1 = checkBenchmark1(process);
		temp_val2 = checkBenchmark2(process);

		/*for checking benchmark process exists or not */
		if(temp_val1)
			bm_1_tf = true;
		if(temp_val2)
			bm_2_tf = true;

		if(temp_val1 && bm_1_stat == 2){
			bm_1_stat = 3;
			printf("**Benchmark1 : Second Execution\n\n");
		}
		if(temp_val2 && bm_2_stat == 2){
			bm_2_stat = 3;
			printf("**Benchmark2 : Second Execution\n\n");
		}
		if(temp_val1 && bm_1_stat == 3){
			bm_1_pid = atoi((char *)process[0].c_str());
		}
		if(temp_val2 && bm_2_stat == 3){
			bm_2_pid = atoi((char *)process[0].c_str());
		}

		storeInfo(process);
	}
	/*check if benchmark has ended*/
	if(bm_1_stat == 1 && bm_1_tf == false){
		bm_1_stat = 2;
		printf("**Benchmark1 : First Execution End\n\n");
	}
	if(bm_2_stat == 1 && bm_2_tf == false){
		bm_2_stat = 2;
		printf("**Benchmark2 : First Execution End\n\n");
	}
	if(bm_1_stat == 4 && bm_1_tf == false){
		printf("**Benchmark1 : Second Execution End\n\n");
		bm_1_stat = 5;
		++end;
	}
	if(bm_2_stat == 4 && bm_2_tf == false){
		printf("**Benchmark2 : Second Execution End\n\n");
		bm_2_stat = 5;
		++end;
	}

	closedir(dp);
}

vector<string> infoExtract(char* file_path)
{
	/*Extract information stored in proc/stat by unit*/
	vector<string> proc_info;
	FILE *fp = NULL;
	char buffer[700];
	char *cp;

	if((fp = fopen(file_path, "r")) == NULL)
	{
		printf("Error: Inaccessible File\n");
		exit(0);
	}
	fgets(buffer, 700, fp);
	cp = strtok(buffer, " ");
	while (cp != NULL)
	{
		proc_info.push_back(cp);
		cp = strtok(NULL, " ");
	}

	fclose(fp);
	return proc_info;
}

int storeInfo(vector<string> proc_info)
{
	/*Store process information in DB
	  Return value 0: newly stored 1:Duplicate process info already exist*/
	string pid;
	string name;
	char* cpid;
	char* cname;
	char* temp_int;
	double cpu_usage;
	int i;
	char dbnum[10];
	char dbusage[10];

	pid = proc_info[0];
	name = proc_info[1];

	cpid = (char *)pid.c_str();
	cname = (char *)name.c_str();

	/*Check if same process name already exists in DB*/
	if(db_cnt/4 >= 1)
	{
		for(i=3; i < db_cnt; i += 4)
		{
			if(name.compare(db[i]) == 0)
				return 1;
		}
	}

	cpu_usage = cpuUsageCalc(proc_info);

	/*change int, double value to string*/
	sprintf(dbnum,"%d", (db_cnt/4)+1);
	sprintf(dbusage,"%.2f", cpu_usage);

	/*Save information in DB*/
	db.push_back(dbnum);
	db.push_back(pid);
	db.push_back(name);
	db.push_back(dbusage);

	db_cnt += 4;

	printf("#%d    %s    %s    %.2f%%\n", (db_cnt/4), cpid, cname, cpu_usage);

	if(!(name.compare("(benchmark1)")) && bm_1_stat == 0)
	{
		bm_1_stat = 1;
		printf("**Benchmark1 : First Execution\n\n");
	}
	if(!(name.compare("(benchmark2)")) && bm_2_stat == 0)
	{
		bm_2_stat = 1;
		printf("**Benchmark2 : First Execution\n\n");
	}

	return 0;
}

double cpuUsageCalc(vector<string> proc_info)
{
	FILE* fp = NULL;
	char buffer[100];
	int i, index, num = 0;
	string str;
	string substr;

	double uptime;
	int utime, stime, cutime, cstime, starttime;
	int total_time;
	double seconds, cpu_usage;
	double hertz;

	/*Take cpu time elements from process information*/
	utime = atoi(proc_info[13].c_str());
	stime = atoi(proc_info[14].c_str());
	cutime = atoi(proc_info[15].c_str());
	cstime = atoi(proc_info[16].c_str());
	starttime = atoi(proc_info[21].c_str());

	/*Number of clock ticks per second of my system*/
	hertz = (double)sysconf(_SC_CLK_TCK);

	/*Extract uptime from proc/uptime*/
	if((fp = fopen("/proc/uptime", "r")) == NULL)
	{
		printf("Error: Inaccessible File\n");
		exit(0);
	}
	fgets(buffer, 100, fp);
	str = buffer;
	for(i = 0; i < str.length(); ++i)
	{
		if(str[i] != ' ')
		{
			++num;
		}
		else
		{
			substr = str.substr(0, num);
			break;
		}
	}
	uptime = atof(substr.c_str());
	fclose(fp);

	/*Calculate total time spent for the process*/
	total_time = utime + stime;
	total_time = total_time + cutime + cstime;
	//include the time from children processes

	seconds =  uptime - ((double)(starttime) / hertz);
	cpu_usage = 100 * ((total_time / hertz) / seconds);

	return cpu_usage;
}

int checkBenchmark1(vector<string> proc_info)
{
	/*Check if it is benchmark1 true : 1 false : 0*/
	char* name;
	name = (char *)proc_info[1].c_str();

	if(strcmp(name,"(benchmark1)") == 0)
	{
		return 1;
	}
	else
		return 0;
}
int checkBenchmark2(vector<string> proc_info)
{
	/*Check if it is benchmark1 true : 1 false : 0*/
	char* name;
	name = (char *)proc_info[1].c_str();

	if(strcmp(name,"(benchmark2)") == 0)
	{
		return 1;
	}
	else
		return 0;
}
void callSyscall(char* name)
{
	int i;
	char* cpid;
	char* ccpu_usage;
	string strname;
	int pid;
	double cpu_usage;
	int bm_num;

	strname = name;

	for(i=3; i < db_cnt; i += 4)
	{
		if(strname.compare(db[i]) == 0) //same name exist
		{
			break;
		}
	}
	cpid = (char *)db[i-1].c_str();
	ccpu_usage = (char *)db[i+1].c_str();

	pid = atoi(cpid);
	cpu_usage = atof(ccpu_usage);

	if(strname.compare("(benchmark1)"))
		bm_num = 2;
	else
		bm_num = 1;

	if(bm_num == 2)
	{
		printf("**Benchmark2 CPU Usage : %.2f CPU bound\n", cpu_usage);
		if(bm_2_pid != -1){
			syscall(FASTER, bm_2_pid);
			printf("**Syscall 326 is called with pid %d\n\n", bm_2_pid);
		}
		bm_2_stat = 4;
	}
	if(bm_num == 1)
	{
		printf("**Benchmark1 CPU Usage : %.2f I/O bound\n", cpu_usage);
		if(bm_1_pid != -1){
			syscall(SLOWER, bm_1_pid);
			printf("**Syscall 327 is called with pid %d\n\n", bm_1_pid);
		}
		bm_1_stat = 4;
	}
}
