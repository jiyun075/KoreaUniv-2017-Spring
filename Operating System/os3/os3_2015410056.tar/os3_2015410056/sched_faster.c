#include <linux/linkage.h>
#include <linux/kernel.h>
#include <linux/sched.h>

signed int faster_pid;

asmlinkage void sys_sched_faster(int proc_pid) {
	faster_pid = proc_pid;
    printk("Syscall : faster\n");
}

EXPORT_SYMBOL(faster_pid);
