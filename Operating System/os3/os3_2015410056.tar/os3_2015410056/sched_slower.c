#include <linux/linkage.h>
#include <linux/kernel.h>
#include <linux/sched.h>

signed int slower_pid;

asmlinkage void sys_sched_slower(int proc_pid) {
	slower_pid = proc_pid; 
    printk("Syscall : slower\n");
}

EXPORT_SYMBOL(slower_pid);
