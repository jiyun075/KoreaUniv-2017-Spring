#include <linux/kernel.h>
#define LEN 20

//Circular Queue
int queue[LEN]; //Queue Array
int head; //head of queue (has value that come in last)
int tail; //tail of queue (has no value)
int n_head; //next index of head (if head is the last index, it will be 0)
int n_tail; //next index of tail
int result; //value to dequeue

asmlinkage void sys_my_enqueue (int n)
{
        int i;
        int check;
        int temp_n_head; //temporary n_head for printing queue

        printk("New System Call Saying %d\n", n);

        //Compute n_head & n_tail
        if (head == LEN-1)
                n_head = 0;
        else
                n_head = head+1;
        if (tail == LEN-1)
                n_tail = 0;
        else
                n_tail = tail+1;

        //Check whether input n exists or not
        i = n_tail;
        check = 0;

        if (n_tail > n_head)
        {
                while (i < LEN)
                {
                        if (queue[i] == n)
                                check = 1;
                        ++i;
                }
                i = 0;
                while (i < n_head)
                {
                        if (queue[i] == n)
                                check = 1;
                        ++i;
                }
        }
        else if (n_tail < n_head)
        {
                while (i < n_head)
                {
                        if (queue[i] == n)
                                check = 1;
                        ++i;
                }
        }

        //Enqueue
        if (check != 1)
        {
                if (n_head == tail)
                        printk("Queue is full\n");
                else
                {
                        head = n_head;
                        queue[head] = n;
                        printk("Enqueue: %d\n", n);
                }
        }
        else
                printk("Same value exists\n");

        //Print Queue
        i = n_tail;
        printk("Queue: ");

        //Compute temp_n_head
        if (head == LEN-1)
                temp_n_head = 0;
        else
                temp_n_head = head+1;

        if (n_tail > temp_n_head)
        {
                while (i < LEN)
                {
                        printk(" %d", queue[i]);
                        ++i;
                }
                i = 0;
                while (i < temp_n_head)
                {
                        printk(" %d", queue[i]);
                        ++i;
                }
        }
        else if (n_tail < temp_n_head)
        {
                while (i < temp_n_head)
                {
                        printk(" %d", queue[i]);
                        ++i;
                }
        }
        else
                printk("Empty");
        printk("\n");

}

asmlinkage int sys_my_dequeue (void)
{
        int j;
        int temp_n_tail;
        printk("Dequeue: ");

        //Compute n_head & n_tail
        if (head == LEN-1)
                n_head = 0;
        else
                n_head = head+1;
        if (tail == LEN-1)
                n_tail = 0;
        else
                n_tail = tail+1;

        //Dequeue
        if (head == tail)
        {
                printk("Nothing to dequeue\n");
                result = 0; // 0 -> initial value
        }
        else
        {
                tail = n_tail;
                result = queue[tail];
                queue[tail] = 0; // remove value
                printk("%d\n", result);
        }

        //Print Queue
        printk("Queue: ");
        //Compute temp_n_tail
        if (tail == LEN-1)
                temp_n_tail = 0;
        else
                temp_n_tail = tail+1;
        j = temp_n_tail;

        if (temp_n_tail > n_head)
        {
                while (j < LEN)
                {
                        printk(" %d", queue[j]);
                        ++j;
                }
                j = 0;
                while (j < n_head)
                {
                        printk(" %d", queue[j]);
                        ++j;
                }
        }
        else if (temp_n_tail < n_head)
        {
                while (j < n_head)
                {
                        printk(" %d", queue[j]);
                        ++j;
                }
        }
        else
                printk("Empty");
        printk("\n");
        return result;
}
