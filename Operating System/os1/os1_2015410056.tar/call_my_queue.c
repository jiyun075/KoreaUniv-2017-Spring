#include <unistd.h>
#include <stdio.h>

int main (void)
{
	int r;
	
	//Enqueue 3 -> 2-> 1
	syscall(326, 3);
	printf("Enqueue 3\n");
	syscall(326, 2);
	printf("Enqueue 2\n");
	syscall(326, 1);
	printf("Enqueue 1\n");

	//Dequeue
	r = syscall(327);
	printf("Dequeue %d\n", r);

	return 0;
}
